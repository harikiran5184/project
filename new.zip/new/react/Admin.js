import React, { useState } from 'react'
import "./admin.css"
export default function Admin() {
    const [branch,setBranch]=useState([])
    const [year,setYear]=useState([])
    const [section,setSection]=useState([])
    function handel(e){
        e.preventDefault()
        console.log(branch,year,section)
        sessionStorage.setItem("abranch",branch)
        sessionStorage.setItem("ayear",year)
        sessionStorage.setItem("asection",section)
        window.location.href="/../admin/assign"
    }
    function create(){
        sessionStorage.setItem("abranch",branch)
        sessionStorage.setItem("ayear",year)
        sessionStorage.setItem("asection",section)
        window.location.href="/../test1"
    }
  return (
    <div className='admin' >
        <form onSubmit={handel} >
        <label htmlFor='branch' >BRANCH:</label>
        <select name='branch' onChange={e=>{setBranch(e.target.value)}} >
            <option>Select Branch</option>
            <option>CSE</option>
            <option>CSD</option>
            <option>CSM</option>
            <option>ECE</option>
            <option>EEE</option>
            <option>MECH</option>
            <option>IT</option>
            <option>CHEM</option>
          </select>
          <br/>
            <label htmlFor='year' >YEAR: </label>
            <select name='year' onChange={e=>{setYear(e.target.value)}} >
            <option>Select year</option>
                <option value={"1"} >1st</option>
                <option value={"2"} >2nd</option>
                <option value={"3"} >3rd</option>
                <option value={"4"} >4th</option>
            </select>
            <br/>
            <label htmlFor='section'  >SECTION: </label>
            <select name='section' onChange={e=>{setSection(e.target.value)}} >
            <option>Select section</option>
                <option value={"A"} >A</option>
                <option value={"B"} >B</option>
                <option value={"C"} >C</option>
            </select>
            <br/>
            <button>SUBMIT</button>
            
        </form>
        <button onClick={create} >CREATE</button>
    </div>
  )
}
