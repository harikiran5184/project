function ic(){
    console.log("hello world")
}
document.getElementById("ic").addEventListener("click",ic())