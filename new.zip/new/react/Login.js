import React from 'react';
import './Log.css';
import axios from 'axios';
import { useState } from 'react';
export default function Login() {
  const [lusername,setLusername]=useState([])
  const [lpassword,setLpassword]=useState([])
 // const [status,setStatus]=useState([])
  const [susername,setSusername]=useState([])
  const [spassword,setSpassword]=useState([])
  const [sbranch,setSbranch]=useState([])
  const [sphone,setSphone]=useState([])
  function handel(e){
    e.preventDefault();
    try{
       axios.post("http://localhost:6500",{
        lusername,lpassword
    }).then(res=>{
      if(res.data==="login successfully 0"){
        sessionStorage.setItem('name',lusername)
        window.location.href="/../home"
      }
      else if(res.data==="login successfully 1"){
        
          window.location.href="/../admin"
        
      }
      else{
        console.log(res.data)
      }
    })
    .catch(e=>{console.log(e)})
  }
  catch(e){
    console.log(e)
  }
  }
  
  function handel1(e){
    e.preventDefault()
    try{
      axios.post("http://localhost:6500/signup",{
        susername,sbranch,sphone,spassword
      }).then(res=>{console.log(res.data)
      if(res.data==="signup is successfull"){

        window.location.reload();
      }
      }).catch(e=>{console.log(e)})
    }
    catch(e){
      console.log(e)
    }
  }
  return (
    <div style={{width:"100%",height:"100vh"}}>
      <div  className='login main' id='login'>
        <h1>Login</h1>
        <form>
          <label>Username :</label>
          <input type='text' placeholder='Enter your Username' onChange={(e)=>{setLusername(e.target.value)}}  name='username'></input><br/>
          <label>Password :</label>
          <input type='password' placeholder='Enter your Password' onChange={(e)=>{setLpassword(e.target.value)}} className='pass'  name='Password'></input><br/>
          <button onClick={handel} name='submit'>Login</button>
        </form>
      </div>
      {/* <div  className='ic' id='ic' ><h1>^</h1></div> */}
      <div className='login one'  id='sign'  >
        <h1>Signup</h1>
        <form onSubmit={handel1} >
          <label>Username :</label>
          <input type='text' placeholder='Enter your Username' onChange={e=>setSusername(e.target.value)} name='username'></input><br/>
          <label className='e1'>Branch :</label>
          <select name='branch' onChange={e=>setSbranch(e.target.value)} className='pass'>
            <option>Select Branch</option>
            <option>CSE</option>
            <option>CSD</option>
            <option>CSM</option>
            <option>ECE</option>
            <option>EEE</option>
            <option>MECH</option>
            <option>IT</option>
            <option>CHEM</option>
          </select><br/>
          <label className='e'>Phone :</label>
          <input type='tel' placeholder='Enter your Phone no' name='phno' onChange={e=>setSphone(e.target.value)} className='pass'></input><br/>
          <label>Password :</label>
          <input type='password' placeholder='Enter your Password' className='pass' onChange={e=>setSpassword(e.target.value)}  name='Password'></input><br/>
          <button type='submit' name='submit'>Sign UP</button>
          
        </form>
      </div>
    </div>
  )
}